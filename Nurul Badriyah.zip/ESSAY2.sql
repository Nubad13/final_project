-- Tabel dimensi dim_user
CREATE TABLE dim_user (
    user_key SERIAL PRIMARY KEY,
    user_id INT,
    user_name VARCHAR(100),
    country VARCHAR(50)
);

-- Masukkan data ke tabel dim_user dari raw_users
INSERT INTO dim_user (user_id, user_name, country)
SELECT DISTINCT user_id, user_name, country
FROM raw_users;

-- Tabel dimensi dim_post
CREATE TABLE dim_post (
    post_key SERIAL PRIMARY KEY,
    post_id INT,
    post_text VARCHAR(500),
    post_date DATE,
    user_id INT REFERENCES dim_user(user_id)
);

-- Masukkan data ke tabel dim_post dari raw_posts
INSERT INTO dim_post (post_id, post_text, post_date, user_id)
SELECT DISTINCT post_id, post_text, post_date, user_id
FROM raw_posts;
-- Tabel dimensi dim_date
CREATE TABLE dim_date (
    date_key SERIAL PRIMARY KEY,
    date_value DATE
);

-- Masukkan data ke tabel dim_date dari raw_posts
INSERT INTO dim_date (date_value)
SELECT DISTINCT post_date
FROM raw_posts;
-- Tabel fakta fact_post_performance
CREATE TABLE fact_post_performance (
    fact_key SERIAL PRIMARY KEY,
    date_key INT REFERENCES dim_date(date_key),
    post_key INT REFERENCES dim_post(post_key),
    likes INT,
    views INT -- Kamu dapat menambahkan metrik lain jika diperlukan
);

-- Populate fact_post_performance dengan agregasi data dari raw_likes
INSERT INTO fact_post_performance (date_key, post_key, likes, views)
SELECT d.date_key, p.post_key, COUNT(l.like_id) AS likes, COUNT(*) AS views
FROM dim_date d
JOIN dim_post p ON p.post_date = d.date_value
LEFT JOIN raw_likes l ON l.post_id = p.post_id AND l.like_date = d.date_value
GROUP BY d.date_key, p.post_key;
-- Tabel fakta fact_daily_posts
CREATE TABLE fact_daily_posts (
    fact_key SERIAL PRIMARY KEY,
    date_key INT REFERENCES dim_date(date_key),
    user_key INT REFERENCES dim_user(user_key),
    posts_count INT
);

-- Populate fact_daily_posts dengan data agregat dari raw_posts
INSERT INTO fact_daily_posts (date_key, user_key, posts_count)
SELECT d.date_key, u.user_key, COUNT(p.post_id) AS posts_count
FROM dim_date d
JOIN dim_user u ON TRUE
LEFT JOIN raw_posts p ON p.user_id = u.user_id AND p.post_date = d.date_value
GROUP BY d.date_key, u.user_key;
